namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Biztosan ki akarsz l�pni?", "Meger�s�t�s", MessageBoxButtons.OKCancel) != DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserControlTank userControlTank = new UserControlTank();
            panel1.Controls.Clear();
            panel1.Controls.Add(userControlTank);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserControlShip userControlShip = new UserControlShip();
            panel1.Controls.Clear();
            panel1.Controls.Add(userControlShip);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UserControlAircraft userControlAircraft = new UserControlAircraft();
            panel1.Controls.Clear();
            panel1.Controls.Add(userControlAircraft);
        }
    }
}