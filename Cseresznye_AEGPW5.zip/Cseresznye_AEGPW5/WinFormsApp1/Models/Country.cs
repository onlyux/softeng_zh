﻿using System;
using System.Collections.Generic;

namespace WinFormsApp1.Models;

public partial class Country
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Alliance { get; set; }

    public int? Casualties { get; set; }

    public virtual ICollection<Aircraft> Aircraft { get; set; } = new List<Aircraft>();

    public virtual ICollection<Ship> Ships { get; set; } = new List<Ship>();

    public virtual ICollection<Tank> Tanks { get; set; } = new List<Tank>();
}
