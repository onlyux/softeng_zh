﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class UserControlAircraft : UserControl
    {
        WwiidatabaseContext context = new WwiidatabaseContext();

        public UserControlAircraft()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            aircraftBindingSource.DataSource = context.Aircraft.ToList();
        }

        private void torles_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentRow == null) 
            {
                return;
            }

            if(MessageBox.Show("Biztosan törlöd?", "Megerősítés", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                context.Aircraft.Remove((Aircraft)dataGridView1.CurrentRow.DataBoundItem);
                context.SaveChanges();
                aircraftBindingSource.DataSource = context.Aircraft.ToList();
            }
        }
    }
}
