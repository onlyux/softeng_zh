﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class UserControlShip : UserControl
    {
        WwiidatabaseContext context = new WwiidatabaseContext();

        public UserControlShip()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            shipBindingSource.DataSource = context.Ships.ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var x = (from i in context.Ships
                     where i.Name.Contains(textBox1.Text)
                     select i).ToList();
            shipBindingSource.DataSource = x;
        }
    }
}
