﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class UserControlTank : UserControl
    {
        WwiidatabaseContext context = new WwiidatabaseContext();

        public UserControlTank()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            tankBindingSource.DataSource = context.Tanks.ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == null)
            {
                MessageBox.Show("Hiba!");
                return;
            }
            else
            {
                var x = (from i in context.Tanks
                         where i.Crew == int.Parse(textBox1.Text)
                         select i).ToList();

                if (int.Parse(textBox1.Text) == 0)
                {
                    tankBindingSource.DataSource = context.Tanks.ToList();
                }

                tankBindingSource.DataSource = x;
            }
        }
    }
}
