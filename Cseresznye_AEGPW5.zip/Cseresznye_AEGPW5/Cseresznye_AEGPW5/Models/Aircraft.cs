﻿using System;
using System.Collections.Generic;

namespace Cseresznye_AEGPW5.Models;

public partial class Aircraft
{
    public int Id { get; set; }

    public int CountryId { get; set; }

    public string Name { get; set; } = null!;

    public int NoBuilt { get; set; }

    public int Range { get; set; }

    public virtual Country Country { get; set; } = null!;
}
