﻿using Cseresznye_AEGPW5.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Cseresznye_AEGPW5.Controllers
{
    [Route("api/tank")]
    [ApiController]
    public class TankController : ControllerBase
    {
        WwiidatabaseContext context = new WwiidatabaseContext();

        // GET: api/<TankController>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(context.Tanks.ToList());
        }

        // GET api/<TankController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var x = (from i in context.Tanks
                     where i.Id == id
                     select i).FirstOrDefault();
            if (x == null)
            {
                return NotFound("Nincs ilyen id");
            }
            return Ok(x);
        }

        [HttpGet("{name}")]
        public IActionResult Get(string name)
        {
            var x = (from i in context.Tanks
                     where i.Name == name
                     select i).FirstOrDefault();
            if (x.Name != name)
            {
                return NotFound("Nincs ilyen nevű tank");
            }
            return Ok(x);
        }

        // POST api/<TankController>
        [HttpPost("CreateTank")]
        public IActionResult CreateTank(int countryId, string name, int noBuilt, int crew)
        {
            Tank newTank = new Tank
            {
                CountryId = countryId,
                Name = name,
                NoBuilt = noBuilt,
                Crew = crew
            };

            context.Tanks.Add(newTank);
            context.SaveChanges();
            return Ok(newTank);
        }

        [HttpPost("ModifyTank")]
        public IActionResult ModifyTank(int id, string name)
        {
            var x = (from i in context.Tanks
                     where i.Id == id
                     select i);

            if (x == null)
            {
                return NotFound("Nincs ilyen id");
            }

            //x.Name = name;

            context.SaveChanges();
            return Ok(x);
        }

        //DELETE api/<TankController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var x = (from i in context.Tanks
                     where i.Id == id
                     select i).FirstOrDefault();
            if (x == null)
            {
                return NotFound("Nincs ilyen id");
            }

            context.Tanks.Remove(x);
            context.SaveChanges();
            return Ok(x);
        }
    }
}
