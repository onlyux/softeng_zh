﻿function betolt() {
    fetch("api/tank")
        .then(response => {
            if (!response.ok) {
                throw Error("Hiba történt!");
            }
            response.json()
        })
        .then(data => {
            let tbody = document.getElementById("tb_tank");
            tbody.innerHTML = "";

            data.forEach(tank => {
                sor = document.createElement("tr");
                sor.innerHTML = `
                <td>${tank.id}</td>
                <td>${tank.countryId}</td>
                <td>${tank.name}</td>
                <td>${tank.noBuilt}</td>
                <td>${tank.crew}</td>
                `;
                tbody.appendChild(sor);
            })
        })
}

document.getElementById("tankBetolt").addEventListener("click", betolt)